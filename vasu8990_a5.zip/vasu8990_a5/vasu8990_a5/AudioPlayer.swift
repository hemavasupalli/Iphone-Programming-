//
//  AudioPlayer.swift
//  vasu8990_a5
//
//  Created by Hema vasupalli on 2022-03-21.
//

import UIKit;
import AVFoundation;
 
class AudioPlayer: NSObject {
    static let audioPlayer = AudioPlayer();
    
    private var backgroundMusicPlayer: AVAudioPlayer?;
    private var effectPlayer: AVAudioPlayer?;
    
    func playBackgroundMusic() {
      //https://stackoverflow.com/questions/32036146/how-to-play-a-sound-using-swift
            guard let sound = Bundle.main.path(forResource: "crash", ofType:"mp3") else {
                return }
            let url = URL(fileURLWithPath: sound)

            do {
                backgroundMusicPlayer = try AVAudioPlayer(contentsOf: url)
                backgroundMusicPlayer?.play()
                
            } catch let error {
                print(error.localizedDescription)
            }
        
                
        backgroundMusicPlayer!.numberOfLoops = -1
        backgroundMusicPlayer!.prepareToPlay()
        backgroundMusicPlayer!.play()
    } //playBackgroundMusic
    
    func stopBackgroundMusic() {
        if (backgroundMusicPlayer != nil) {
            backgroundMusicPlayer!.stop()
        }
    }
    
    func playSoundEffect(filename: String, fileExtension: String) {
        
        guard let sound = Bundle.main.path(forResource: "crash", ofType:"mp3") else {
            return }
        let url = URL(fileURLWithPath: sound)

        do {
            effectPlayer = try AVAudioPlayer(contentsOf: url)
            effectPlayer?.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
        
                
        effectPlayer!.numberOfLoops = 0;
        effectPlayer!.prepareToPlay();
        effectPlayer!.play();
    }
}
