//
//  PhysicsCategory.swift
//  vasu8990_a5
//
//  Created by Hema vasupalli on 2022-03-20.
//

import Foundation
struct PhysicsCategory {
    
    static let None      : UInt32 = 0
    static let All       : UInt32 = UInt32.max
    static let bullet  : UInt32  = 0b1
    static let flower : UInt32 = 0b10
    static let player : UInt32 = 0b11
}
