//
//  File.swift
//  vasu8990_a5
//
//  Created by Hema vasupalli on 2022-03-21.
//

import Foundation
import UIKit;
import SpriteKit;

class Controller: NSObject {
    private var windowWidth : CGFloat?;
    private var midX : CGFloat?;
    private var minX : CGFloat?;
    private var maxX : CGFloat?;
    private var minY : CGFloat?;
    private var maxY : CGFloat?;
    
    let LEFT_RIGHT_BTN_OVERFLOW = CGFloat(20.0);
    let BTN_X_PADDING = CGFloat(115.0);
    let BTN_Y_PADDING = CGFloat(115.0);
    let NUM_BTNS = CGFloat(3.0);
    
    init(windowWidth : CGFloat, midX: CGFloat, minX: CGFloat, maxX: CGFloat, minY: CGFloat, maxY: CGFloat) {
        self.windowWidth = windowWidth;
        self.midX = midX;
        self.minX = minX;
        self.maxX = maxX;
        self.minY = minY;
        self.maxY = maxY;
    }
    
    public func createControlBar(leftButton: inout SKSpriteNode, rightButton: inout SKSpriteNode, jumpButton: inout SKSpriteNode) {
        leftButton.name = "leftButton";
        leftButton.yScale = 1.5;
        leftButton.position = CGPoint(x: self.minX! + BTN_X_PADDING, y: self.minY! + BTN_Y_PADDING);
        leftButton.setScale(0.50);
        leftButton.size.width = self.windowWidth! / NUM_BTNS + LEFT_RIGHT_BTN_OVERFLOW;
        
        rightButton.name = "rightButton";
        rightButton.yScale = 1.5;
        rightButton.position = CGPoint(x: self.maxX! - BTN_X_PADDING, y: self.minY! + BTN_Y_PADDING);
        rightButton.setScale(0.50);
        rightButton.size.width = self.windowWidth! / NUM_BTNS + LEFT_RIGHT_BTN_OVERFLOW;
        
        jumpButton.name = "jumpButton";
        jumpButton.yScale = 1.5;
        jumpButton.position = CGPoint(x: self.midX!, y: self.minY! + BTN_Y_PADDING);
        jumpButton.setScale(0.50);
        jumpButton.size.width = self.windowWidth! / NUM_BTNS;
    }
}
