//
//  Player.swift
//  vasu8990_a5
//
//  Created by Hema vasupalli on 2022-03-21.
//

import Foundation
import UIKit;
import SpriteKit;

class Player : NSObject {
    
    let DFNDR_Y_PADDING = CGFloat(230.0);
    let DFNDR_SPEED = CGFloat(10.0);
    let DFNDR_PADDING = CGFloat(50.0);
    let BULLET_PADDING = CGFloat(50.0);
    
    private var midX: CGFloat?;
    private var minY: CGFloat?;
    private var minX: CGFloat?;
    private var maxX: CGFloat?;
    private var maxY: CGFloat?;
    //let jumpDistance = 15.0 // half of the total x-distance
    let jumpSpeed = 0.5 // in seconds
   // let jumpHeight = self.accessibilityFrame.midY
    
    
    init(midX: CGFloat, minY: CGFloat, minX: CGFloat, maxX: CGFloat, maxY: CGFloat) {
        self.midX = midX;
        self.minY = minY;
        self.minX = minX;
        self.maxX = maxX;
        self.maxY = maxY;
    }
    
    public func createplayer(player: inout SKSpriteNode) {
        player.name = "player";
        player.yScale = 2.0;
        player.position = CGPoint(x: self.midX!, y: self.minY! - 10 + DFNDR_Y_PADDING);
        player.setScale(0.50);
        
        player.physicsBody = SKPhysicsBody(rectangleOf: player.size);
        player.physicsBody?.categoryBitMask = PhysicsCategory.player;
        //player.physicsBody?.contactTestBitMask = PhysicsCategory.Invader;
       // player.physicsBody?.contactTestBitMask = PhysicsCategory.Rock;
    }

    public func moveplayerLeft(player: inout SKSpriteNode) {
        if (player.position.x - DFNDR_SPEED >= self.minX! + DFNDR_PADDING) {
            player.position.x = player.position.x - DFNDR_SPEED;
          //  run(SKAction.playSoundFileNamed("crash.mp3", waitForCompletion: false))
        }
    }

    public func moveplayerRight(player: inout SKSpriteNode) {
        if (player.position.x + DFNDR_SPEED <= self.maxX! - DFNDR_PADDING) {
            player.position.x = player.position.x + DFNDR_SPEED;
        }
    }
    //let jumpHeight = self.accessibilityFrame.midY
    public func jump( player: inout SKSpriteNode) {
        // move up
        let jumpUpAction = SKAction.moveBy(x: 0 , y: player.position.y + 400 , duration: jumpSpeed)
         
        // move down
                let jumpDownAction = SKAction.moveBy(x: 0, y: -player.position.y - 400 , duration: jumpSpeed)
     //   let jumpUp = SKAction.moveByX(0, y: 50, duration: 0.3)
                // sequence of move up then down
                let jumpSequence = SKAction.sequence([jumpUpAction, jumpDownAction])
         
                // make player run sequence
            player.run(jumpSequence)

        
       AudioPlayer.audioPlayer.playSoundEffect(filename: "artillery2", fileExtension: "m4a");
  
    }
    
    public func destroyplayer(player: inout SKSpriteNode, scream: inout SKSpriteNode) {
        player.removeFromParent();
        
        scream.name = "scream";
        scream.yScale = 1.5;
        scream.position = CGPoint(x: player.position.x, y: player.position.y);
        scream.setScale(1.5);
        
        AudioPlayer.audioPlayer.playSoundEffect(filename: "scream", fileExtension: "mp3");
    }
}
