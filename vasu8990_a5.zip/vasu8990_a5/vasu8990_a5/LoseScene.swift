//
//  Lose.swift
//  vasu8990_a5
//
//  Created by Hema vasupalli on 2022-03-20.
//

import Foundation
import SpriteKit
import UIKit;
import SpriteKit;

class LoseScene : SKScene {
    private var scoreboard : PlayScene?;
    private var youLose: SKSpriteNode?;
    
     override init(size: CGSize) {
      super.init(size: size)
         let sound = SKAction.playSoundFileNamed("crash", waitForCompletion: false)
         run(sound)
      // 1
      backgroundColor = SKColor.white
        let score1 = scoreboard?.score
      // 2
      let message1 =   "Game Over"
        // scoreboard?.scorelabel.text0
         let message2 =  "you scored \(score1 ?? 0) points"
      
      // 3
      let label1 = SKLabelNode(fontNamed: "Chalkduster")
      label1.text = message1
      label1.fontSize = 40
      label1.fontColor = SKColor.black
      label1.position = CGPoint(x: size.width/2, y: size.height/2)
      addChild(label1)
         let label2 = SKLabelNode(fontNamed: "Chalkduster")
         label2.text = message2
         label2.fontSize = 40
         label2.fontColor = SKColor.black
         label2.position = CGPoint(x: size.width/2, y: size.height/3)
         addChild(label2)
      
      // 4
      run(SKAction.sequence([
        SKAction.wait(forDuration: 3.0),
        SKAction.run() { [weak self] in
          // 5
          guard let `self` = self else { return }
          let reveal = SKTransition.flipHorizontal(withDuration: 0.5)
          let scene = GameScene(size: size)
          self.view?.presentScene(scene, transition:reveal)
        }
        ]))
      }
          required init?(coder aDecoder: NSCoder)
          {
                   fatalError("init(coder:) has not been implemented")
          }}


