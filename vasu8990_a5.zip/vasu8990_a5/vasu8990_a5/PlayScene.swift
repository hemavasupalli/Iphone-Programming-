//
//  PlayScene.swift
//  vasu8990_a5
//
//  Created by Hema vasupalli on 2022-03-21.
//

import Foundation
import UIKit;
import SpriteKit;

class PlayScene : SKScene, SKPhysicsContactDelegate {
    
    private var controller : Controller?;
    private var playerUtils : Player?;
    private var leftButton : SKSpriteNode?;
    private var rightButton : SKSpriteNode?;
    private var jumpButton : SKSpriteNode?;
    var score = 0
    var scorelabel = SKLabelNode();
   // label().text = = "\(score)";

    //private var score : SKSpriteNode?;
    var i = 0.0
    var count = 0
    let DFNDR_Y_PADDING = CGFloat(230.0);
     
  private var player : SKSpriteNode?;
    let spriteFrequency = 60
  
    var timer = 0
    private func initPlayer() {
        scorelabel.text = "\(score)";
        scorelabel.fontName = "Helvetica Neue"
        scorelabel.fontSize = 100
        scorelabel.fontColor = SKColor.orange
        scorelabel.position = CGPoint(x: self.frame.width * 0.1, y : self.frame.height * 0.9)
        self.addChild(scorelabel)
       // score = SKSpriteNode(score);
        player = SKSpriteNode(imageNamed: "player");
        
        self.player?.physicsBody?.isDynamic = true
   
       // physicsBody?.affectedByGravity = CGVector(dx: 0.0, dy: -2.0)
        player?.physicsBody = SKPhysicsBody(rectangleOf: player!.size)
         player?.physicsBody?.isDynamic = false // 2
        player?.physicsBody?.categoryBitMask = PhysicsCategory.player //
        player?.physicsBody?.contactTestBitMask = PhysicsCategory.bullet | PhysicsCategory.flower// Contact with bullet
        player?.physicsBody?.collisionBitMask = PhysicsCategory.None

        self.playerUtils!.createplayer(player: &player!);
        self.addChild(player!);
    }
    
    
    private func initController() {
        leftButton = SKSpriteNode(imageNamed: "left-arrow-unit");
        rightButton = SKSpriteNode(imageNamed: "right-arrow-unit");
        jumpButton = SKSpriteNode(imageNamed: "bullet-unit");
        
        self.controller!.createControlBar(leftButton: &leftButton!, rightButton: &rightButton!, jumpButton: &jumpButton!);
        
        self.addChild(leftButton!);
        self.addChild(rightButton!);
        self.addChild(jumpButton!);
    }
    //addBullet()
    
    func random() -> CGFloat {
      return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }

    func random(min: CGFloat, max: CGFloat) -> CGFloat {
      return random() * (max - min) + min
    }

    func addBullet() {

      // Create sprite
      let bullet = SKSpriteNode(imageNamed: "bullet")

      // Determine where to spawn the monster along the Y axis
      //let actualY = random(min: bullet.size.height/2, max: self.frame.midY + i)

      // Position the monster slightly off-screen along the right edge,
      // and along a random position along the Y axis as calculated above
      bullet.position = CGPoint(x: size.width + bullet.size.width/2, y: self.frame.midY + i)
        bullet.setScale(2);
        bullet.physicsBody = SKPhysicsBody(rectangleOf: bullet.size) // define boundary of body
        bullet.physicsBody?.isDynamic = true // 2
        bullet.physicsBody?.categoryBitMask = PhysicsCategory.bullet //
        bullet.physicsBody?.contactTestBitMask = PhysicsCategory.player // Contact with bullet
        bullet.physicsBody?.collisionBitMask = PhysicsCategory.None // No bouncing on collision
      // Add the monster to the scene
      addChild(bullet)
        physicsWorld.gravity = CGVector(dx:0, dy:0)
    physicsWorld.contactDelegate = self
      // Determine speed of the monster
      let actualDuration = random(min: CGFloat(2.0), max: CGFloat(4.0))

      // Create the actions
      let actionMove = SKAction.move(to: CGPoint(x: -bullet.size.width/2, y: self.frame.midY + i),
                                     duration: TimeInterval(actualDuration))
      let actionMoveDone = SKAction.removeFromParent()
      bullet.run(SKAction.sequence([actionMove, actionMoveDone]))
    
    i  += 50
 if (i==200)
 {
     i=0
 }
    }
    
    
    func addFlower() {
          let flower = SKSpriteNode(imageNamed: "flower")
    
            flower.position = CGPoint(x: size.width + flower.size.width/2, y: self.frame.midY + i)
        flower.setScale(2);
          addChild(flower)
    
                  physicsWorld.gravity = CGVector(dx:0, dy:0)
              physicsWorld.contactDelegate = self
        flower.physicsBody = SKPhysicsBody(rectangleOf: flower.size) // define boundary of body
        flower.physicsBody?.isDynamic = true // 2
        flower.physicsBody?.categoryBitMask = PhysicsCategory.flower //
        flower.physicsBody?.contactTestBitMask = PhysicsCategory.player // Contact with bullet
        flower.physicsBody?.collisionBitMask = PhysicsCategory.None // No bouncing on collision
          let actualDuration = random(min: CGFloat(2.0), max: CGFloat(4.0))
    
          // Create the actions
          let actionMove = SKAction.move(to: CGPoint(x: -flower.size.width/2, y: self.frame.midY + i),
                                         duration: TimeInterval(actualDuration))
          let actionMoveDone = SKAction.removeFromParent()
            flower.run(SKAction.sequence([actionMove, actionMoveDone]))
        i  += 50
     if (i==200)
     {
         i=0
     }
        }
    
  
override func update(_ currentTime: CFTimeInterval) {
                      /* Called before each frame is rendered */
                  //var timer = 0
    backgroundColor = SKColor.white
                  timer = timer + 1 // initialized to 0 at the launch of the app
                      if (timer == spriteFrequency) {
                          let flip = arc4random_uniform(2)
                          if(flip == 0)
                          {
                              addBullet()
                              SKAction.wait(forDuration: 2.0)
                          }
                          else
                          {
                              addFlower()
                              SKAction.wait(forDuration: 2.0)
                          }
                          // add a sprite
                            timer = 0
}
}
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        /* Called when a touch begins */
        for touch: AnyObject in touches {
            let location = touch.location(in:self);
            let theNode = self.atPoint(location);
            let sound = SKAction.playSoundFileNamed("crash", waitForCompletion: false)
            run(sound)
            if theNode.name == leftButton!.name {
                self.playerUtils!.moveplayerLeft(player: &player!)
            } else if theNode.name == rightButton!.name {
                self.playerUtils!.moveplayerRight(player: &player!)
            } else if theNode.name == jumpButton!.name {
                self.playerUtils?.jump(player: &player!)
             // jump(super.touchesBegan(touches, with: event)
            }
        }// for
    }
    public func endGame() {
        let losescene = LoseScene(size: self.size)
        self.view?.presentScene(losescene, transition: SKTransition.doorsCloseHorizontal(withDuration: 1.0));
    }
    

    func removeNode(node: SKSpriteNode) {
        node.removeFromParent();
    }
    
    func flowerDidCollideWithPlayer(flower :SKSpriteNode, player:SKSpriteNode) {
       // run(SKAction.playSoundFileNamed("crash.caf", waitForCompletion: false)) // sound does not play! sounds only play if we do not present a new scene!
        print("Hit flower")
        removeNode(node: flower)
       
    }
    func bulletDidCollideWithPlayer(bullet :SKSpriteNode, player:SKSpriteNode) {
       // run(SKAction.playSoundFileNamed("crash.caf", waitForCompletion: false)) // sound
        print("Hit bullet")
        removeNode(node: bullet)
       // removeNode(node: flower)
        //print("Hit bullet")
            //bullet.removeFromParent()
        count += 10
        if( count == 30 )
        {
            endGame()
        }
    }
    
    
    func didBegin(_ contact: SKPhysicsContact) {
         
         // bodyA and bodyB collide, we have to sort them by their bitmasks
        var firstBody : SKPhysicsBody
               var secondBody : SKPhysicsBody
               var thirdBody : SKPhysicsBody
               var fourthBody : SKPhysicsBody

               if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
                   firstBody = contact.bodyA
                   secondBody = contact.bodyB
               } else {
                   firstBody = contact.bodyB
                   secondBody = contact.bodyA
               }

               if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
                   thirdBody = contact.bodyA
                   fourthBody = contact.bodyB
               } else {
                   thirdBody = contact.bodyB
                   fourthBody = contact.bodyA
               }

         
        if ((firstBody.categoryBitMask & PhysicsCategory.player != 0) &&
            (secondBody.categoryBitMask & PhysicsCategory.flower != 0)) {
            bulletDidCollideWithPlayer(bullet: firstBody.node as! SKSpriteNode , player: secondBody.node as! SKSpriteNode)
            run(SKAction.playSoundFileNamed("crash.mp3", waitForCompletion: false))
            let wait = SKAction.wait(forDuration: 0.5)
            let block = SKAction.run {
            
             self.score = self.score + 10
                    self.scorelabel.text = "\(self.score)"

                }

                let sequence = SKAction.sequence([wait, block])

            scorelabel.run(SKAction.repeat(sequence, count: 1))
           
             
         } else if ((thirdBody.categoryBitMask & PhysicsCategory.player != 0) && (fourthBody.categoryBitMask & PhysicsCategory.bullet != 0)) {
             
             flowerDidCollideWithPlayer(flower: thirdBody.node as! SKSpriteNode , player: fourthBody.node as! SKSpriteNode)
             let wait = SKAction.wait(forDuration: 0.5)
             let block = SKAction.run {
             
              self.score = self.score + 10
                     self.scorelabel.text = "\(self.score)"

                 }

                 let sequence = SKAction.sequence([wait, block])

             scorelabel.run(SKAction.repeat(sequence, count: 1))
             
            
         }
         
     }
    
    
     //didBeginContact
    override init(size: CGSize) {
     
        super.init(size: size);
        //backgroundColor = SKColor.black;
        self.physicsWorld.gravity = CGVector(dx: 0, dy: 0) // no gravity
        self.physicsWorld.contactDelegate = self;
        
        playerUtils = Player(midX: self.frame.midX, minY: self.frame.minY, minX: self.frame.minX, maxX: self.frame.maxX, maxY: self.frame.maxY);
        controller = Controller(windowWidth: self.frame.width, midX: self.frame.midX, minX: self.frame.minX, maxX: self.frame.maxX, minY: self.frame.minY, maxY: self.frame.maxX);
        initPlayer();
        initController();
       
    }
    required init?(coder aDecoder: NSCoder)
    {
             fatalError("init(coder:) has not been implemented")
    }
}


