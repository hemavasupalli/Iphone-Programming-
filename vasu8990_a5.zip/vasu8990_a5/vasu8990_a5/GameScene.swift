//
//  GameScene.swift
//  vasu8990_a5
//
//  Created by Hema vasupalli on 2022-03-20.
//

import SpriteKit
import GameplayKit

func +(left: CGPoint, right: CGPoint) -> CGPoint {
  return CGPoint(x: left.x + right.x, y: left.y + right.y)
}

func -(left: CGPoint, right: CGPoint) -> CGPoint {
  return CGPoint(x: left.x - right.x, y: left.y - right.y)
}

func *(point: CGPoint, scalar: CGFloat) -> CGPoint {
  return CGPoint(x: point.x * scalar, y: point.y * scalar)
}

func /(point: CGPoint, scalar: CGFloat) -> CGPoint {
  return CGPoint(x: point.x / scalar, y: point.y / scalar)
}

#if !(arch(x86_64) || arch(arm64))
  func sqrt(a: CGFloat) -> CGFloat {
    return CGFloat(sqrtf(Float(a)))
  }
#endif

extension CGPoint {
  func length() -> CGFloat {
    return sqrt(x*x + y*y)
  }
  
  func normalized() -> CGPoint {
    return self / length()
  }
}





class GameScene: SKScene,  SKPhysicsContactDelegate {
    
    
    private var label : SKLabelNode?
    private var spinnyNode : SKShapeNode?
    
//    let player = SKSpriteNode(imageNamed: "player")
//    var bulletsdestroyed = 0
//    var flowersdestryed = 0
//    var score = 0
    
    private var playButton: SKSpriteNode?;
    private var instructionButton: SKSpriteNode?;
    private var playMusicButton: SKSpriteNode?;
    private var stopMusicButton: SKSpriteNode?;
    

    let MAIN_MENU_OFFSET = CGFloat(70.0);

    let INSTRUCTIONS_Y_PADDING = CGFloat(150.0);
    private let ap = AudioPlayer();
        
    override func didMove(to view: SKView) {
        backgroundColor = SKColor.white;
        
        playButton = SKSpriteNode(imageNamed: "PlayButton.png");
        playButton!.name="playButton";
        playButton?.yScale = 1.5;
        playButton!.position = CGPoint(x: self.frame.midX, y: self.frame.midY + MAIN_MENU_OFFSET*3);
        
        instructionButton = SKSpriteNode(imageNamed: "InstructionButton.png");
        instructionButton!.name = "instructionButton";
        instructionButton?.yScale = 1.5;
        instructionButton!.position = CGPoint(x: self.frame.midX, y: self.frame.midY  + MAIN_MENU_OFFSET*2);
        
        playMusicButton = SKSpriteNode(imageNamed: "PlayMusic.png");
        playMusicButton!.name = "playMusicButton";
        playMusicButton?.yScale = 1.5;
        playMusicButton!.position = CGPoint(x: self.frame.midX, y: self.frame.midY  + MAIN_MENU_OFFSET);
        
        stopMusicButton = SKSpriteNode(imageNamed: "StopMusic.png");
        stopMusicButton!.name = "stopMusicButton";
        stopMusicButton?.yScale = 1.5;
        stopMusicButton!.position = CGPoint(x: self.frame.midX, y: self.frame.midY);
        
        self.addChild(playButton!);
        self.addChild(instructionButton!);
        self.addChild(playMusicButton!);
        self.addChild(stopMusicButton!);
   
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        /* Called when a touch begins */
        for touch: AnyObject in touches {
            let location = touch.location(in:self);
            let theNode = self.atPoint(location);
            
            if theNode.name == playButton!.name {
                let playscene = PlayScene(size: self.size);
                let transition = SKTransition.doorway(withDuration: 1.0);
                self.view?.presentScene(playscene, transition: transition)
                //self.view?.presentScene(PlayScene, transition: transition);
            } else if theNode.name == instructionButton!.name {
                let instructionScene = InstructionScene(size: self.size);
                let transition = SKTransition.doorway(withDuration: 1.0);
                
                self.view?.presentScene(instructionScene, transition: transition);
            } else if theNode.name == playMusicButton!.name {
               AudioPlayer.audioPlayer.playBackgroundMusic();
            } else if theNode.name == stopMusicButton!.name {
               AudioPlayer.audioPlayer.stopBackgroundMusic();
            }
        }// for
    }
          
}
