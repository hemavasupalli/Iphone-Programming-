//
//  SharingPerson.swift
//  vasu8990_a3
//
//  Created by Hema vasupalli on 2022-02-17.
//

import UIKit;
import Foundation;

class SharingPerson {
    static let sharedPersons = SharingPerson();
    var personCollection = PersonCollection()

    func setPerson(personcollection : PersonCollection){
        self.personCollection = personcollection
//
//    }
//
       
        // computed property to get the url to the dictionary
        var fileURL : URL {
            let documentDirectoryURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            return documentDirectoryURL.appendingPathComponent("Codable2021.file")
        }
        
        func saveList() throws {
            let jsonEncoder = JSONEncoder()
            var jsonData = Data()
            let theList = SharingPerson.sharedPersons.personCollection.getPersonList()
            do {
                jsonData = try jsonEncoder.encode(theList)
                print("personList encoded")
                print(jsonData)
            }
            catch {
                print("cannot encode personList")
            }
            do {
                try jsonData.write(to: fileURL, options: [])
            } catch { }
                
        } // saveList
        
        func loadList() throws -> [Person] // return persons
        {
            let jsonDecoder = JSONDecoder()
            var persons = [Person]()
            var data = Data()
            do {
                data = try Data(contentsOf: fileURL)
            } catch {
                print("cannot read the archive")
            }
            do{
               persons  = try jsonDecoder.decode([Person].self, from: data)
            } catch {
                print("cannot decode personList from the archive")
            }
            return persons
        }
    }}

    
