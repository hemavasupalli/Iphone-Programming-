//
//  PersonCollection.swift
//  vasu8990_a3
//
//  Created by Hema vasupalli on 2022-02-17.
//

import Foundation
import UIKit
 
 
class PersonCollection: Codable{
     var list = [Person]()
    
     var current:Int  // index to the current person in PersonCollection
     static  var UNKNOWN_PERSON = Person(image: UIImage(named: "question-mark.png"), name: "Name unknown", bio: "No bio")
   
    init() {
        
        current = 0;
       
        list.append((Person(image: UIImage(named: "abraham.jpeg"), name: " Abraham Lincoln" , bio: "Abraham Lincoln was an American lawyer"))!)
        list.append((Person(image: UIImage(named:"gandi.jpeg"), name: "Mahatma Gandhi", bio: "Gandhi was an Indian lawyer"))!)
        list.append((Person(image: UIImage(named:"hitler.jpeg"), name: "Adolf Hitler", bio: "Adolf Hitler was an Austrian-born German politician who was the dictator of Germany"))!)
        list.append((Person(image: UIImage(named: "einstein.jpeg"), name: "Albert Einstein", bio: " Einstein is best known for developing the theory of relativity"))!)

    
        
    }
        
        func addPerson(person: Person) {
            list.append(person)
        }
        
        func getPerson(at index: Int) -> Person? {
            if index < 0 || index >= list.count {
                return nil}
            return list[index]
        }
        
        func getPersonList() -> [Person] {
            return self.list
        }
        
        func setPersonList(persons: [Person]) {
            self.list = persons
        }
        
      
        
    
// helper functions

    func person()->Person {
        return self.list[current];

    }


    func nextIndex() {
        if (self.current == self.list.count - 1) {
            self.current = 0;
        } else {
            self.current += 1;
        }
    }



    func getCurrentIndex() -> Int {
        return self.current;
    }

    func addPerson(name: String, bio: String, image: UIImage) {
        if (name != "" && bio != "") {
            self.list.append(Person(image: image, name: name, bio: bio)!);
        }
    }

    func deletePerson() {
        if (self.list.count > 0) {
            self.list.remove(at: self.current);
        }
        if (list.count > 0 && current > list.count - 1) {
            self.current = self.list.count - 1;
        }
    }

    func Empty() -> Bool {
        return !(self.list.count > 0);
    }
}
