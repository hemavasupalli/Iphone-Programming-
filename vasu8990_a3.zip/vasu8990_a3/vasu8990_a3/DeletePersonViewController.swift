//
//  DeletePersonViewController.swift
//  vasu8990_a3
//
//  Created by Hema vasupalli on 2022-02-17.
//



import UIKit

class DeletePersonViewController: UIViewController {


    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var name: UILabel!

    func reAdd() {
        if (SharingPerson.sharedPersons.personCollection.Empty() == true){
            image.image = UIImage(named: "question-mark.png");
            name.text = "Please go to add tab and add a person ";

        } else {
            image.image = SharingPerson.sharedPersons.personCollection.person().image;
            name.text = SharingPerson.sharedPersons.personCollection.person().name;

        }
    }

    private func showAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert);

        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alertController, animated: true, completion: nil);
    }

    private func showDeletePersonSuccessAlert() {
        let title = "Delete a Person";
        let message = "The person \"\(name.text!)\" is deleted";
        showAlert(title: title, message: message);
    }

    private func showDeletePersonErrorAlert() {
        let title = "Empty person collection";
        let message = "The person collection  is empty";
        showAlert(title: title, message: message);
    }

    override func viewDidLoad() {
        super.viewDidLoad();
        reAdd();
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated);
        reAdd();
    }

    
    @IBAction func Delete(_ sender: Any) {
    if (SharingPerson.sharedPersons.personCollection.Empty() == false) {
            SharingPerson.sharedPersons.personCollection.deletePerson();
            showDeletePersonSuccessAlert();
            reAdd();
        } else {
            showDeletePersonErrorAlert();
        }
    }

    @IBAction func Next(_ sender: Any) {
        if (SharingPerson.sharedPersons.personCollection.Empty() == false) {
            SharingPerson.sharedPersons.personCollection.nextIndex();
            reAdd();
        } else {
            showDeletePersonErrorAlert();
        }
    }
}

