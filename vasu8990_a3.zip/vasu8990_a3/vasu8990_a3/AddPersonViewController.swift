//
//  AddPersonViewController.swift
//  vasu8990_a3
//
//  Created by Hema vasupalli on 2022-02-17.
//

import UIKit;

class AddPersonViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    @IBOutlet weak var namefield: UITextField!
    
    @IBOutlet weak var biofield: UITextView!
    
    @IBOutlet weak var imagefield: UIImageView!
    private let imagePicker = UIImagePickerController();
    
      
    
   
    @objc private func imageTapped(tapGestureRecognizer: UITapGestureRecognizer) {
        let imagePickerController = UIImagePickerController();
        imagePickerController.allowsEditing = false;
        imagePickerController.sourceType = .photoLibrary;
        imagePickerController.delegate = self;
        present(imagePickerController, animated: true, completion: nil);
    }


    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let tempImage = info[UIImagePickerController.InfoKey.originalImage] as! UIImage;
        imagefield.image  = tempImage;
        self.dismiss(animated: true, completion: nil);
    }


    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil);
    }

    override func viewDidLoad() {
        super.viewDidLoad();
            biofield.layer.borderWidth = 2.0
            biofield.layer.borderColor = UIColor.gray.cgColor

        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)));
        imagefield.isUserInteractionEnabled = true;
        imagefield.addGestureRecognizer(tapGestureRecognizer);
    }

    private func showAlert(message: String) {
        let title = "Add a Person";
        let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert);

        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alertController, animated: true, completion: nil);
    }

    private func showAddPersonSuccessAlert() {
        let message = "The name \"\(namefield.text!)\" has been added";
        showAlert(message: message);
    }

    private func showAddPersonErrorAlert() {
        let message = "You must fill out both the name and bio";
        showAlert(message: message);
    }

    private func clearForm() {
        namefield.text = "";
        biofield.text = "";
        imagefield.image  = UIImage(named: "question-mark.png");
    }

    @IBAction func AddPerson(_ sender: Any) {


        let name = namefield.text!;
        let bio = biofield.text!;
        let image = imagefield.image!;

        if (name != "" && bio != "") {
            SharingPerson.sharedPersons.personCollection.addPerson(name: name, bio: bio, image: image)
            showAddPersonSuccessAlert();
            clearForm();
        } else {
            showAddPersonErrorAlert();
        }
    }

    @IBAction func textFieldDoneEditing(sender: UITextField) {
        sender.resignFirstResponder();
    }

    @IBAction func backgroundTap(sender: UIControl) {
        namefield.resignFirstResponder();
        biofield.resignFirstResponder();
    }
}
