//
//  ViewController.swift
//  vasu8990_a3
//
//  Created by Hema vasupalli on 2022-02-17.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var image: UIImageView!
    
    @IBOutlet weak var bio: UITextView!
    
    
    @IBAction func Bio_button(_ sender: UIButton) {
        bio.text = SharingPerson.sharedPersons.personCollection.person().bio
    }
    
    @IBAction func Next_button(_ sender: UIButton) {
        SharingPerson.sharedPersons.personCollection.nextIndex()
        reAdd()
    }
    
    func reAdd(){
        if (SharingPerson.sharedPersons.personCollection.list.isEmpty == true )
        {
            image.image = UIImage(named: "question-mark.png");
            name.text = "Name Unknown";
            bio.text = "...";
        }
        else {
            //SharingPerson.sharedPersons.personCollection.getPersonList();
            image.image = SharingPerson.sharedPersons.personCollection.person().image
            name.text = SharingPerson.sharedPersons.personCollection.person().name
            bio.text = "..."

        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        _ = SharingPerson();
        bio.layer.borderWidth = 2.0 
            bio.layer.borderColor = UIColor.gray.cgColor
       



    }}



