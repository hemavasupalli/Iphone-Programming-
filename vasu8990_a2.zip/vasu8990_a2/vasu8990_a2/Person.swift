//
//  Person.swift
//  vasu8990_a2
//
//  Created by Hema vasupalli on 2022-02-18.
//

import Foundation


struct Person {

    let image: String

    let name: String

    let bio: String

}
