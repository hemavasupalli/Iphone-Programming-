//
//  Persons.swift
//  vasu8990_a2
//
//  Created by Hema vasupalli on 2022-02-18.
//

import Foundation


struct Persons{

    static var personList = [Person]()

    static var current:Int = 0 // index to the current person in personList
    
    

   

    init(){

       // var person =
        Persons.personList.append(Person(image:"abraham.jpeg", name: " Abraham Lincoln", bio:"Abraham Lincoln was an American lawyer and statesman who served as the 16th president of the United States from 1861 until his assassination in 1865"))
        
        Persons.personList.append(Person(image: "gandi.jpeg", name: "Mahatma Gandhi", bio: "Gandhi was an Indian lawyer, anti-colonial nationalist and political ethicist who employed nonviolent resistance to lead the successful campaign for India's independence from British rule"))
        Persons.personList.append(Person(image: "hitler.jpeg", name: "Adolf Hitler", bio: "Adolf Hitler was an Austrian-born German politician who was the dictator of Germany from 1933 until his death in 1945. He rose to power as the leader of the Nazi Party"))
        Persons.personList.append(Person(image: "einstein.jpeg", name: "Albert Einstein", bio: "Albert Einstein was a German-born theoretical physicist, widely acknowledged to be one of the greatest physicists of all time. Einstein is best known for developing the theory of relativity"))

 

       } // init

 

// helper functions to manage the current index and returns the next person

 
 
// Example: return the next person
    
    
   static  func getCurrentIndex() -> Int {
        return self.current;
    }

    static func nextPerson()  {

        if (self.current == self.personList.count - 1) {
            self.current = 0;
        } else {
            self.current += 1;
        }
        
    }

        
        
        
       

    }

 

  // Persons
