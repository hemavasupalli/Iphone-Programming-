//
//  ViewController.swift
//  vasu8990_a2
//
//  Created by Hema vasupalli on 2022-02-18.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var bio: UIButton!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var image: UIImageView!
    
    @IBAction func Bio_button(_ sender: Any) {
        Persons.personList.getCurrentIndex();
        bio.text = Persons.personList[current].bio
    }
    @IBAction func Next(_ sender: Any) {
    }
    
    
    @IBAction func Bio_button(_ sender: UIButton) {
        bio.text = SharingPerson.sharedPersons.personCollection.person().bio
    }
    
    @IBAction func Next_button(_ sender: UIButton) {
        SharingPerson.sharedPersons.personCollection.nextIndex()
        reAdd()
    }
    
    func reAdd(){
        if (SharingPerson.sharedPersons.personCollection.list.isEmpty == true )
        {
            image.image = UIImage(named: "question-mark.png");
            name.text = "Name Unknown";
            bio.text = "...";
        }
        else {
            //SharingPerson.sharedPersons.personCollection.getPersonList();
            image.image = SharingPerson.sharedPersons.personCollection.person().image
            name.text = SharingPerson.sharedPersons.personCollection.person().name
            bio.text = "..."

        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        _ = Persons();
        bio.layer.borderWidth = 2.0
            bio.layer.borderColor = UIColor.gray.cgColor
       



    }}
 



