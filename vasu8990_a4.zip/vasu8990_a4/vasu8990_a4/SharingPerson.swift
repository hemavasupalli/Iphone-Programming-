//
//  SharingPerson.swift
//  vasu8990_a4
//
//  Created by Hema vasupalli on 2022-03-06.
//

import UIKit;
import Foundation;

class SharingPerson {
    static let sharedPersons = SharingPerson();
    var personCollection = PersonCollection()

    func setPerson(personcollection : PersonCollection){
        self.personCollection = personcollection
  }
}
