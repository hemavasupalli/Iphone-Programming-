////
////  ViewController.swift
////  MyFirstTableView
////
////  Created by Chinh T Hoang on 2018-08-20.
////  Copyright © 2018 wlu. All rights reserved.
////
//
//import UIKit
//import OSLog
//
//class TableViewCell: UITableViewCell{
//    
//    @IBOutlet weak var TVLabel: UILabel!
//    
//    @IBOutlet weak var TVImage: UIImageView!
//    
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//    }
//
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//   
//        // Configure the view for the selected state
//    }
//}
//
//class ViewController : UITableViewController {
//    
//  @IBOutlet   var tableView1: UITableView!
//    
//var persons = [Person]()
//    let cellIdentifier = "reuseIdentifier"
//
//override func viewDidLoad() {
//    super.viewDidLoad()
//    
//    
//    
//    // Use the edit button item provided by the table view controller.
//    navigationItem.leftBarButtonItem = editButtonItem
//    
//    // Load any saved meals, otherwise load sample data.
//    if let savedPersons = loadPersons() {
//        persons += savedPersons
//    }
//    else {
//        // Load the sample data.
//        loadSamplePersons()
//        //loadSamplepersons()
//    }
//}
//
//override func didReceiveMemoryWarning() {
//    super.didReceiveMemoryWarning()
//    // Dispose of any resources that can be recreated.
//}
//
////MARK: - Table view data source
//
//override func numberOfSections(in tableView: UITableView) -> Int {
//    return 1
//}
//
//override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//    return persons.count
//}
//
//
//
//override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        
//        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? TableViewCell
//        if (cell == nil) {
//            cell = TableViewCell(
//                style: UITableViewCell.CellStyle.default,
//                reuseIdentifier: cellIdentifier)
//        }
//        
//    let person = persons[indexPath.row]
//    cell?.TVImage.image = persons[indexPath.row].getPhoto()
//        
//        cell?.TVLabel.text = persons[indexPath.row].getName()
//        
//        return cell!
//    }
//
//
//
//// Override to support conditional editing of the table view.
//override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
//    // Return false if you do not want the specified item to be editable.
//    return true
//}
//
//
//
//// Override to support editing the table view.
//override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//    if editingStyle == .delete {
//        // Delete the row from the data source
//        persons.remove(at: indexPath.row)
//      savePersons()
//        tableView.deleteRows(at: [indexPath], with: .fade)
//    } else if editingStyle == .insert {
//        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
//    }
//}
//
//
//
////MARK: - Navigation
//
//// In a storyboard-based application, you will often want to do a little preparation before navigation
//override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//    
//    super.prepare(for: segue, sender: sender)
//    
//    switch(segue.identifier ?? "") {
//        
//    case "AddItem":
//        os_log("Adding a new meal.", log: OSLog.default, type: .debug)
//        
//    case "ShowDetail":
//        guard let DetailViewController = segue.destination as? AddPersonViewController else {
//            fatalError("Unexpected destination: \(segue.destination)")
//        }
//        
//        guard let selectedPersonCell = sender as? TableViewCell else {
//            fatalError("Unexpected sender: \(String(describing: sender))")
//        }
//        
//        guard let indexPath = tableView.indexPath(for: selectedPersonCell) else {
//            fatalError("The selected cell is not being displayed by the table")
//        }
//        
//        let selectedPerson = persons[indexPath.row]
//        DetailViewController.newPerson = selectedPerson
//        
//    default:
//        fatalError("Unexpected Segue Identifier; \(String(describing: segue.identifier))")
//    }
//}
//
//
////MARK: Actions
//
//@IBAction func unwindPersonList(sender: UIStoryboardSegue) {
//    if let sourceViewController = sender.source as? AddPersonViewController,
//       let person = sourceViewController.newPerson {
//        
//        if let selectedIndexPath = tableView.indexPathForSelectedRow {
//            // Update an existing meal.
//            persons[selectedIndexPath.row] = person
//            tableView.reloadRows(at: [selectedIndexPath], with: .none)
//        }
//        else {
//            // Add a new meal.
//            let newIndexPath = IndexPath(row: persons.count, section: 0)
//            //newPerson.append(person)
//            persons.append(person)
//            tableView.insertRows(at: [newIndexPath], with: .automatic)
//        }
//        
//        // Save the meals.
//        savePersons()
//    }
//}
//
////MARK: Private Methods
//
//private func loadSamplePersons() {
//    
////    guard let photo1 = UIImage(named: "gandhi")
////    let photo2 = UIImage(named: "abraham")
////    let photo3 = UIImage(named: "einstein")
//     let person1 = Person(name: "Abraham Lincon", photo: UIImage(named: "abraham.jpg")!, bio: "President of USA"  )
//   // persons.append(person1)
//   
//    
//    let person2 = Person(name: " Eistein", photo: UIImage(named: "einstein.jpg")!,  bio: "A great Scientist" )
//   // persons.append(person2)
//    
//    let person3 = Person(name: " Hitler", photo: UIImage(named: "hitler.jpg")!,
//            bio: "A great Leader" )
//   // persons.append(person3)
//    
//
//    persons += [person1, person2, person3]
//}
//
//private func savePersons() {
//    let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(persons, toFile: Person.ArchiveURL.path)
//    if isSuccessfulSave {
//        os_log("Meals successfully saved.", log: OSLog.default, type: .debug)
//    } else {
//        os_log("Failed to save meals...", log: OSLog.default, type: .error)
//    }
//}
//
//private func loadPersons() -> [Person]?  {
//    return NSKeyedUnarchiver.unarchiveObject(withFile: Person.ArchiveURL.path) as? [Person]
//}
//
//}
