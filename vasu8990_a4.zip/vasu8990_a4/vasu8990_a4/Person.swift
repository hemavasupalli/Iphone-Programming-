//
//  Person.swift
//  MyFirstTableView
//
//  Created by Chinh T Hoang on 2018-08-20.
//  Copyright © 2018 wlu. All rights reserved.
//

import Foundation
import UIKit

class Person {
    
    var name: String
    var photo: UIImage
    var movie: Movie
    
    init(name: String, photo: UIImage, movie: Movie){
        self.name = name
        self.photo = photo
        self.movie = movie
    }
    
    func getName()  -> String{
        return self.name
    }
    
    func getPhoto() -> UIImage {
        return self.photo
    }
    
    func getMovie() -> Movie {
        return self.movie
    }
}// Person

class Movie {
    var title: String
    var poster: UIImage
    var critic: String
    
    init(title: String, poster: UIImage, critic: String){
        self.title = title
        self.poster = poster
        self.critic = critic
    }
    
    func getTitle() -> String {
        return title
    }
    
    func getPoster() -> UIImage {
        return poster
    }
    
    func getCritic() -> String {
        return critic
    }
} // Movie


