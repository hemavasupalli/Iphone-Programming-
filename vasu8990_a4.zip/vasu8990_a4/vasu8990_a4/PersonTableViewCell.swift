//
//  PersonTableViewCell.swift
//  vasu8990_a4
//
//  Created by Hema vasupalli on 2022-03-07.
//

import Foundation
import UIKit

class PersonTableViewCell: UITableViewCell {
    
    @IBOutlet weak var TVLabel: UILabel!

    @IBOutlet weak var TVImage: UIImageView!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}


