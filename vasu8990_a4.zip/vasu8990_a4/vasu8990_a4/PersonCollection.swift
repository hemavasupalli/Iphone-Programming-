//
//  PersonCollection.swift
//  vasu8990_a4
//
//  Created by Hema vasupalli on 2022-03-06.
//

import Foundation
import Foundation
import UIKit
 
 
class PersonCollection {
     var list = [Person]()
    
     var current:Int
   
  
   init() {
       
       current = 0;
   }
       
       func addPerson(person: Person) {
           list.append(person)
       }
       
       func getPerson(at index: Int) -> Person? {
           if index < 0 || index >= list.count {
               return nil}
           return list[index]
       }
       
       func getPersonList() -> [Person] {
           return self.list
       }
       
       func setPersonList(persons: [Person]) {
           self.list = persons
       }
       
     
       
   
// helper functions

   func person()->Person {
       return self.list[current];

   }


   func nextIndex() {
       if (self.current == self.list.count - 1) {
           self.current = 0;
       } else {
           self.current += 1;
       }
   }



   func getCurrentIndex() -> Int {
       return self.current;
   }

   func addPerson(name: String,  image: UIImage , bio: String) {
       if (name != "" && bio != "") {
           self.list.append(Person(name: name, photo: image, bio: bio));
       }
   }

   func deletePerson() {
       if (self.list.count > 0) {
           self.list.remove(at: self.current);
       }
       if (list.count > 0 && current > list.count - 1) {
           self.current = self.list.count - 1;
       }
   }

   func Empty() -> Bool {
       return !(self.list.count > 0);
   }
}

