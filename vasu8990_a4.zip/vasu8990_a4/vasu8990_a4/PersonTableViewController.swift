//
//  PersonTableViewController.swift
//  vasu8990_a4
//


import UIKit
import os.log

class PersonTableViewController: UITableViewController {
    
    //MARK: Properties
    
    var Persons = [Person]()
    
    var newPerson: Person?


        func getPerson() -> Person? {

            return newPerson

        }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Use the edit button item provided by the table view controller.
        navigationItem.leftBarButtonItem = editButtonItem
        
        // Load any saved Persons, otherwise load sample data.
        if let savedPersons = loadPersons() {
            Persons += savedPersons
        }
        else {
            // Load the sample data.
            loadSamplePersons()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Persons.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Table view cells are reused and should be dequeued using a cell identifier.
        let cellIdentifier = "PersonTableViewCell"
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? PersonTableViewCell  else {
            fatalError("The dequeued cell is not an instance of PersonTableViewCell.")
        }
        
        // Fetches the appropriate Person for the data source layout.
        let Person = Persons[indexPath.row]
        
        cell.TVLabel.text = Person.name
        cell.TVImage.image = Person.photo
        //cell..bio = Person.rating
        
        return cell
    }
    

    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            Persons.remove(at: indexPath.row)
            savePersons()
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    //MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        super.prepare(for: segue, sender: sender)
        
        switch(segue.identifier ?? "") {
            
        case "AddItem":
            os_log("Adding a new Person.", log: OSLog.default, type: .debug)
            
        case "ShowDetail":
            guard let DetailViewController = segue.destination as? PersonViewController else {
                fatalError("Unexpected destination: \(segue.destination)")
            }
            
            guard let selectedPersonCell = sender as? PersonTableViewCell else {
                fatalError("Unexpected sender: \(String(describing: sender))")
            }
            
            guard let indexPath = tableView.indexPath(for: selectedPersonCell) else {
                fatalError("The selected cell is not being displayed by the table")
            }
            
            let selectedPerson = Persons[indexPath.row]
            DetailViewController.Person = selectedPerson
            
        default:
            fatalError("Unexpected Segue Identifier; \(String(describing: segue.identifier))")
        }
    }

    
    //MARK: Actions
    
    @IBAction func unwindToPersonList(sender: UIStoryboardSegue) {
        if let sourceViewController = sender.source as? PersonViewController, let Person = sourceViewController.Person {
            
            if let selectedIndexPath = tableView.indexPathForSelectedRow {
                // Update an existing Person.
                Persons[selectedIndexPath.row] = Person
                tableView.reloadRows(at: [selectedIndexPath], with: .none)
            }
            else {
                // Add a new Person.
                let newIndexPath = IndexPath(row: Persons.count, section: 0)
                
                Persons.append(Person)
                tableView.insertRows(at: [newIndexPath], with: .automatic)
            }
            
            // Save the Persons.
            savePersons()
        }
    }
    
    //MARK: Private Methods
    
    private func loadSamplePersons() {
        
        let person1 = Person(name: "Abraham Lincon", photo: UIImage(named: "abraham.jpg")!, bio: "President of USA"  )
      // persons.append(person1)
      
       
       let person2 = Person(name: " Eistein", photo: UIImage(named: "einstein.jpg")!,  bio: "A great Scientist" )
      // persons.append(person2)
       
       let person3 = Person(name: " Hitler", photo: UIImage(named: "hitler.jpg")!,
               bio: "A great Leader" )
      // persons.append(person3)
       

       Persons += [person1, person2, person3]
    }
    private func savePersons() {
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(Persons, toFile: Person.ArchiveURL.path)
        if isSuccessfulSave {
            os_log("Meals successfully saved.", log: OSLog.default, type: .debug)
        } else {
            os_log("Failed to save meals...", log: OSLog.default, type: .error)
        }
    }
    
    private func loadPersons() -> [Person]?  {
        return NSKeyedUnarchiver.unarchiveObject(withFile: Person.ArchiveURL.path) as? [Person]
    }

}
